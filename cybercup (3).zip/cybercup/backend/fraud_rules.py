"""
fraud_rules.py - the scam-detection "brain".

How it works (simple version):
  1. We keep a list of RULES. Each rule describes one scam tactic
     (asking for an OTP, threatening "digital arrest", pushing urgency...).
  2. Each rule has a weight (how suspicious that tactic is) and patterns
     (words/phrases in English, Hindi and Hinglish that show the tactic).
  3. We check the call transcript against every rule and add up the weights.
  4. Dangerous COMBINATIONS (e.g. "I'm from the CBI" + "send money") get a bonus.
  5. If the text looks like a safety warning ("never share your OTP"), we
     reduce the score so genuine bank awareness messages are not flagged.
  6. The final score becomes LOW / MEDIUM / HIGH with a clear explanation.

To improve the system, add or tune rules below. No AI training needed.
"""
import re

FLAGS = re.I | re.S

# ---- building blocks for "someone is ASKING for a secret code" ----
SECRET = (r"(\b(?:otp|pin|cvv|password|one[- ]time password)\b|ओटीपी|पिन|पासवर्ड|"
          r"aadhaar number|card number|कार्ड नंबर)")
ASK = (r"(\b(?:share|tell|give|send|read|read out|provide|say|batao|bata|bolo|bhej|"
       r"bhejiye|dijiye|dedo|dena|padh|padhiye|sunaiye|sunao|forward|confirm|enter|verify|submit)\b|"
       r"बताइए|बताओ|बता|दीजिए|दीजिये|बोलिए|भेजिए|शेयर|पढ़कर|सुनाइए)")

# A "code that arrived on your phone" without the word OTP, e.g.
# "read out the six digit code", "jo code aapke phone pe aaya hai"
CODE_CTX = (r"((?:\d+|four|five|six|seven|eight|nine)[ -]?digit (?:code|number)|"
            r"verification code|security code|"
            r"\bcode\b.{0,30}(?:came|comes|received|texted|sent|aaya|aayi|sms|message|phone|screen)|"
            r"(?:कोड).{0,30}(?:आया|आए|फोन|मैसेज))")

# Each rule: id, label (shown to the user), weight, patterns
RULES = [
    {"id": "asks_code", "weight": 40,
     "label": "Asks for OTP / PIN / CVV / password / card details",
     "patterns": [ASK + r".{0,40}" + SECRET, SECRET + r".{0,25}" + ASK,
                  ASK + r".{0,60}" + CODE_CTX, CODE_CTX + r".{0,60}" + ASK]},

    {"id": "mentions_code", "weight": 10,
     "label": "Mentions OTP / PIN / card details",
     "patterns": [SECRET]},

    {"id": "remote_access", "weight": 40,
     "label": "Asks to install a remote-access / screen-share app",
     "patterns": [r"any\s?desk", r"team\s?viewer", r"quick\s?support", r"rustdesk",
                  r"screen\s?shar", r"download (the |this )?app",
                  r"app download (karo|kijiye|kar)", r"ऐप डाउनलोड", r"एप डाउनलोड"]},

    {"id": "digital_arrest", "weight": 45,
     "label": "Threatens arrest / 'digital arrest' / legal trouble",
     "patterns": [r"digital arrest", r"डिजिटल अरेस्ट", r"arrest warrant",
                  r"under arrest", r"money laundering", r"narcotics", r"arrest you", r"will be arrested",
                  r"illegal activity", r"aadhaar.{0,40}(illegal|misused)", r"\bwarrant\b",
                  r"gireftar", r"गिरफ्तार", r"parcel.{0,40}(illegal|drugs)",
                  r"पार्सल.{0,40}(ड्रग|अवैध)"]},

    {"id": "impersonation", "weight": 20,
     "label": "Claims to be an official (bank, police, CBI, courier, KYC...)",
     "patterns": [r"\bcbi\b", r"सीबीआई", r"\bpolice\b", r"पुलिस", r"\bcustoms\b",
                  r"\brbi\b", r"\btrai\b", r"cyber cell", r"income tax",
                  r"bank (officer|manager|executive)", r"\bkyc\b",
                  r"\b(hdfc|icici|sbi|axis bank|kotak|pnb|paytm|phonepe)\b", r"telecom (provider|company|department)", r"mobile operator",
                  r"customer (care|support) (executive|team)", r"support team",
                  r"\bcourier\b", r"fedex", r"narcotics bureau"]},

    {"id": "account_threat", "weight": 25,
     "label": "Threatens account/SIM blocking or KYC expiry",
     "patterns": [r"account (will be |is |has been )?(blocked|suspended|closed|frozen)",
                  r"account (band|block)", r"खाता (बंद|ब्लॉक)",
                  r"(problem|issue|gadbad|dikkat) (with|in|hai)? ?(your |aapke )?(savings|account|khata)",
                  r"account (mein|me) (gadbad|problem|dikkat)",
                  r"(connection|bijli|electricity|sim|gas).{0,30}(kat jayega|kat jaayega|will be cut|disconnect|band ho)",
                  r"sim (will be |is )?(blocked|disconnected|band|block)",
                  r"kyc (is )?(expired|pending|update)", r"legal action"]},

    {"id": "urgency", "weight": 15,
     "label": "Creates urgency / time pressure",
     "patterns": [r"\bimmediately\b", r"right now", r"\burgent", r"last warning",
                  r"within (one|two|three|\d+) (minutes?|mins|hours?)", r"\babhi\b", r"\bturant\b",
                  r"\bjaldi\b", r"तुरंत", r"अभी", r"जल्दी"]},

    # not_after: if the caller says "I will transfer...", THEY are paying, not asking you to.
    {"id": "payment", "weight": 35,
     "label": "Asks to transfer money / pay a fee / use a 'safe account'",
     "not_after": r"(\bi will|\bi'll|\bi am going to|\blet me|\bmain\b|\bmai\b|\bmein\b|\bwill)\s.{0,12}$",
     "patterns": [r"transfer (the |your )?(money|amount|funds)", r"send (the |us |some )?money",
                  r"(move|shift|transfer|deposit)\s.{0,25}(everything|all (of )?(your|the) (money|savings)).{0,50}",
                  r"(protected|secure|safe|locker|rbi|government|verification) (locker )?account",
                  r"(move|shift|put) (your |the )?(savings|funds|money|amount)",
                  r"\bpay\b.{0,30}\b(charges?|fee|tax|duty|amount)\b.{0,40}\b(account|number|upi)\b",
                  r"gift card", r"safe account", r"processing fee",
                  r"refundable (deposit|fee)", r"(paise|paisa|पैसे|rupaye)\s(?:(?:turant|abhi|jaldi|aaj|sab|saare)\s)?(?:bhej|transfer|jama)",
                  r"प्रोसेसिंग फीस", r"फीस (भेज|जमा)",
                  r"पैसे (भेज|ट्रांसफर)", r"upi pin", r"scan (this|the) qr",
                  r"pay (a |the )?(fine|fee|penalty)"]},

    {"id": "advance_fee", "weight": 40,
     "label": "Investment / job / prize offer that asks you to pay first",
     "patterns": [r"double(s)? your money", r"guaranteed (profit|returns?)", r"risk[- ]free",
                  r"registration.{0,40}(rupaye|rupees|hazaar|fee|₹)",
                  r"ghar baithe (naukri|kaam)", r"work from home.{0,40}(fee|deposit|pay)",
                  r"(deposit|invest|pay|jama)\s.{0,40}(rupees|rupaye|lakh|thousand|hazaar|₹)"
                  r".{0,40}(account|number|upi)"]},

    {"id": "relative_emergency", "weight": 20,
     "label": "Pretends to be a relative in trouble with a 'new number'",
     "patterns": [r"(i )?(changed|got a new) (my )?(phone )?number", r"naya number",
                  r"\bit'?s me\b.{0,40}(trouble|accident|hospital|police)",
                  r"in trouble", r"accident ho gaya", r"(mera|meri).{0,15}(accident|arrest)"]},

    {"id": "secrecy", "weight": 20,
     "label": "Tells you to keep it secret / not to hang up",
     "patterns": [r"(do not|don't|dont) tell (anyone|anybody|dad|mom|your)",
                  r"keep (this|it) (confidential|secret)",
                  r"(do not|don't) disconnect", r"stay on the line", r"stay with me",
                  r"kisi ko mat bata", r"किसी को मत बताना", r"call mat kat"]},

    {"id": "lottery", "weight": 20,
     "label": "Promises a prize / lottery / reward",
     "patterns": [r"\blottery\b", r"you have won", r"\bprize\b", r"\binaam\b", r"इनाम", r"लॉटरी", r"जीती"]},
]

# Messages that WARN people about scams should not be flagged as scams.
SAFE_GUARDS = [
    r"(never|do not|don't|dont)\s+(share|give|disclose|reveal|forward)\s.{0,30}(otp|pin|cvv|password|it\b)",
    r"(never|will not|won't)\s+ask\s.{0,20}(otp|pin|cvv|password)",
    r"(otp|pin|cvv|ओटीपी|पिन).{0,25}(kisi ko|किसी को).{0,10}(mat|na|न|ना|मत)",
]

# Compile all patterns once, at startup, so analysis is fast.
for _r in RULES:
    _r["compiled"] = [re.compile(p, FLAGS) for p in _r["patterns"]]
SAFE_COMPILED = [re.compile(p, FLAGS) for p in SAFE_GUARDS]

ADVICE = {
    "high": ("STOP. Hang up now. Do not share any OTP, PIN or card details and do not "
             "transfer money or install any app. Call back only on the official number "
             "printed on your bank card or website. Report it on the national cyber-crime "
             "helpline 1930 (cybercrime.gov.in)."),
    "medium": ("Be careful. This call has some warning signs. Do not share OTPs or "
               "PINs. Hang up and call the organisation back on its official number to "
               "verify. If in doubt, report it on 1930."),
    "low": ("No strong scam signs found. Still, never share OTPs, PINs or passwords "
            "with anyone who calls you."),
}


def detect_language(text):
    """Very simple guess: Hindi script, Hinglish (Hindi in English letters), or English."""
    devanagari = sum("\u0900" <= c <= "\u097f" for c in text)
    letters = sum(c.isalpha() for c in text) or 1
    if devanagari / letters > 0.3:
        return "hi"
    hinglish_words = {"hai", "hain", "aap", "aapka", "aapke", "mein", "main", "nahi",
                      "kya", "karo", "kijiye", "batao", "bhejiye", "turant", "abhi",
                      "paise", "khata", "band", "jayega", "bol", "raha", "hoon", "hu",
                      "kaise", "ho", "ghar", "beta", "sir"}
    words = set(re.findall(r"[a-z]+", text.lower()))
    return "hinglish" if len(words & hinglish_words) >= 2 else "en"


def _snippet(match):
    return match.group(0).strip()[:60]


def analyze_text(text):
    """Main function: transcript in -> risk, score, indicators, advice out."""
    text = (text or "").strip()
    indicators = []
    ids = set()
    score = 0

    for rule in RULES:
        # don't double-count: "asks for OTP" already covers "mentions OTP"
        if rule["id"] == "mentions_code" and "asks_code" in ids:
            continue
        for pattern in rule["compiled"]:
            m = pattern.search(text)
            if m and rule.get("not_after") and re.search(
                    rule["not_after"], text[max(0, m.start() - 30):m.start()], FLAGS):
                m = None            # the speaker is the one paying, so skip this match
            if m:
                ids.add(rule["id"])
                score += rule["weight"]
                indicators.append({"id": rule["id"], "label": rule["label"],
                                   "matched": _snippet(m)})
                break

    # Dangerous combinations
    wants_something = ids & {"asks_code", "payment", "remote_access", "advance_fee"}
    applies_pressure = ids & {"impersonation", "account_threat", "digital_arrest",
                              "relative_emergency", "lottery"}
    if wants_something and applies_pressure:
        score += 20
        indicators.append({"id": "combo", "matched": "",
                           "label": "Official-sounding pressure combined with a request for money/codes"})
    if "urgency" in ids and wants_something:
        score += 10

    # Safety / awareness messages
    if any(g.search(text) for g in SAFE_COMPILED):
        score = int(score * 0.3)
        indicators.append({"id": "safe", "matched": "",
                           "label": "Looks like a safety warning, so score was reduced"})

    score = min(score, 100)
    risk = "high" if score >= 60 else "medium" if score >= 30 else "low"
    return {"transcript": text, "language": detect_language(text), "risk": risk,
            "score": score, "indicators": indicators, "advice": ADVICE[risk]}
