"""
transcribe.py - speech-to-text (audio file -> text).

We use Whisper, which understands Hindi, English and mixed Hindi-English.
Whisper is big, so it loads only the first time it is needed (lazy loading).
If Whisper is not installed, the app still works with typed/pasted text.

Model size trade-off (set WHISPER_MODEL env variable):
  tiny/base  = fast, less accurate     small = good balance (default)
"""
import os

_model = None
_backend = None


def _load():
    global _model, _backend
    if _model is not None:
        return
    size = os.environ.get("WHISPER_MODEL", "small")
    try:
        from faster_whisper import WhisperModel          # fast, CPU friendly
        _model = WhisperModel(size, device="cpu", compute_type="int8")
        _backend = "faster-whisper"
    except ImportError:
        import whisper                                    # openai-whisper
        _model = whisper.load_model(size)
        _backend = "openai-whisper"


def available():
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        try:
            import whisper  # noqa: F401
            return True
        except ImportError:
            return False


def transcribe(path):
    """Return (text, detected_language). Needs ffmpeg for non-wav formats."""
    _load()
    if _backend == "faster-whisper":
        # No fixed language: Whisper detects Hindi/English itself.
        segments, info = _model.transcribe(path, beam_size=1, vad_filter=True)
        text = " ".join(seg.text.strip() for seg in segments)
        return text.strip(), info.language
    result = _model.transcribe(path)
    return result["text"].strip(), result.get("language", "")


def transcribe_samples(x, sr=16000):
    """Transcribe a float32 numpy array (live audio chunk). Returns (text, language)."""
    import tempfile
    import wave
    import numpy as np
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    tmp.close()
    try:
        with wave.open(tmp.name, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(pcm.tobytes())
        return transcribe(tmp.name)
    finally:
        os.remove(tmp.name)          # PRIVACY: live audio is never kept
