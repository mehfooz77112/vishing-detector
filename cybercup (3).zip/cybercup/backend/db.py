"""
db.py - tiny SQLite database that stores analysed calls for the dashboard.

PRIVACY: we store the transcript and the result, but NEVER the audio file.
Audio is deleted right after analysis. Users can wipe everything with
DELETE /history.
"""
import json
import os
import sqlite3
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "calls.db")


def _conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    with _conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS calls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT, source TEXT, language TEXT, risk TEXT, score INTEGER,
            deepfake_score REAL, transcript TEXT, indicators TEXT, advice TEXT)""")


def save(result, source):
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO calls (created_at, source, language, risk, score, deepfake_score,"
            " transcript, indicators, advice) VALUES (?,?,?,?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), source, result["language"],
             result["risk"], result["score"], result.get("deepfake_score"),
             result["transcript"], json.dumps(result["indicators"]), result["advice"]))
        return cur.lastrowid


def history(limit=50):
    with _conn() as c:
        rows = c.execute("SELECT * FROM calls ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["indicators"] = json.loads(d["indicators"] or "[]")
        out.append(d)
    return out


def stats():
    with _conn() as c:
        total = c.execute("SELECT COUNT(*) FROM calls").fetchone()[0]
        by_risk = {r["risk"]: r["n"] for r in
                   c.execute("SELECT risk, COUNT(*) AS n FROM calls GROUP BY risk")}
        per_day = [dict(r) for r in c.execute(
            "SELECT substr(created_at,1,10) AS day, COUNT(*) AS total,"
            " SUM(risk='high') AS high FROM calls GROUP BY day ORDER BY day DESC LIMIT 14")]
        rows = c.execute("SELECT indicators FROM calls WHERE risk != 'low'").fetchall()
    tally = {}
    for r in rows:
        for ind in json.loads(r["indicators"] or "[]"):
            if ind["id"] not in ("combo", "safe"):
                tally[ind["label"]] = tally.get(ind["label"], 0) + 1
    top = sorted(tally.items(), key=lambda kv: -kv[1])[:6]
    return {"total": total, "by_risk": {"low": by_risk.get("low", 0),
            "medium": by_risk.get("medium", 0), "high": by_risk.get("high", 0)},
            "per_day": per_day[::-1], "top_indicators": [{"label": k, "count": v} for k, v in top]}


def clear():
    with _conn() as c:
        c.execute("DELETE FROM calls")
