"""
main.py - the API server (the "waiter" between the dashboard and the brain).

Endpoints:
  POST   /analyze   audio file and/or text -> transcript, risk, indicators, advice
  GET    /history   recent analysed calls
  GET    /stats     numbers for the dashboard charts
  DELETE /history   wipe stored data (privacy)
  GET    /health    what features are available on this machine

Run:  uvicorn main:app --reload      then open http://localhost:8000
"""
import os
import tempfile
import time
import base64
import json
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import db
import deepfake
import fraud_rules
import telephony
import transcribe
from live_session import LiveSession
from starlette.concurrency import run_in_threadpool

app = FastAPI(title="Vishing & Deepfake Call Detector")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
db.init()

FRONTEND = os.path.join(os.path.dirname(__file__), "..", "frontend")
MAX_BYTES = 25 * 1024 * 1024


@app.get("/health")
def health():
    return {"status": "ok", "speech_to_text": transcribe.available()}


@app.post("/analyze")
async def analyze(file: Optional[UploadFile] = File(None),
                  text: Optional[str] = Form(None),
                  consent: bool = Form(True),
                  save: bool = Form(True)):
    """Analyse a call. Send an audio file, or text (e.g. a transcript / SMS)."""
    if not consent:
        raise HTTPException(400, "Consent is required to analyse a call.")
    if file is None and not (text and text.strip()):
        raise HTTPException(400, "Send an audio file or some text.")

    started = time.time()
    notes = []
    deepfake_info = {"score": None, "label": "not_checked", "reasons": [], "method": "none"}
    transcript, whisper_lang = (text or "").strip(), ""
    source = "text"

    if file is not None:
        source = "audio"
        data = await file.read()
        if len(data) > MAX_BYTES:
            raise HTTPException(413, "File too large (max 25 MB).")
        suffix = os.path.splitext(file.filename or "")[1] or ".wav"
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        try:
            tmp.write(data)
            tmp.close()
            deepfake_info = deepfake.analyze_audio(tmp.name)
            if not transcript:
                if transcribe.available():
                    try:
                        transcript, whisper_lang = transcribe.transcribe(tmp.name)
                    except Exception as e:
                        notes.append(f"Speech recognition failed: {e}")
                else:
                    notes.append("Speech-to-text not installed; paste the transcript instead.")
        finally:
            os.remove(tmp.name)                 # PRIVACY: audio is never kept

    result = fraud_rules.analyze_text(transcript)
    if whisper_lang and result["language"] == "en" and whisper_lang == "hi":
        result["language"] = "hinglish"

    # A very likely synthetic voice raises the risk by one level when there is
    # at least some scam signal; it never creates a high-risk alert by itself.
    result["deepfake_score"] = deepfake_info["score"]
    result["deepfake"] = deepfake_info
    if (deepfake_info["score"] or 0) >= 0.6 and result["score"] >= 15:
        result["score"] = min(100, result["score"] + 25)
        result["indicators"].append({"id": "deepfake", "matched": "",
                                     "label": "Voice sounds synthetic / possibly cloned"})
        result["risk"] = "high" if result["score"] >= 60 else "medium" if result["score"] >= 30 else "low"
        result["advice"] = fraud_rules.ADVICE[result["risk"]]
    if deepfake_info["label"] == "likely_synthetic":
        result["advice"] += (" The voice may be AI-generated: verify by calling the person "
                             "on a number you already know, or ask a question only they can answer.")

    result["notes"] = notes
    result["processing_seconds"] = round(time.time() - started, 2)
    if save:
        result["id"] = db.save(result, source)
    return result


@app.get("/history")
def history(limit: int = 50):
    return db.history(limit)


@app.get("/stats")
def stats():
    return db.stats()


@app.delete("/history")
def clear_history():
    db.clear()
    return {"status": "cleared"}


@app.get("/")
def index():
    return FileResponse(os.path.join(FRONTEND, "index.html"))



# ------------------------------------------------------------------
# LIVE CALLS (WebSockets): audio streams in, warnings stream out
# ------------------------------------------------------------------
alert_listeners = set()          # dashboards / phones watching for alerts


async def broadcast(message):
    """Send a message to every connected alert listener."""
    for listener in list(alert_listeners):
        try:
            await listener.send_json(message)
        except Exception:
            alert_listeners.discard(listener)


def _save_live(session, source):
    summary = session.summary()
    if summary["transcript"].strip():
        db.save(summary, source)


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    """
    Browser/phone microphone stream.
    1. client sends text  {"type":"start","consent":true}
    2. client sends binary frames: PCM16 little-endian, mono, 16 kHz
    3. server sends JSON updates (risk, score, indicators, advice, transcript, alert)
    4. client sends {"type":"stop"} (or just disconnects)
    """
    await ws.accept()
    session = None
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if msg.get("text") is not None:
                data = json.loads(msg["text"])
                kind = data.get("type")
                if kind == "start":
                    if not data.get("consent"):
                        await ws.send_json({"type": "error", "detail": "Consent is required."})
                        await ws.close()
                        return
                    session = LiveSession()
                    await ws.send_json({"type": "ready", "speech_to_text": transcribe.available()})
                elif kind == "text" and session:          # typed text, handy for demos
                    update = session.add_text(data.get("text", ""))
                    await ws.send_json(update)
                    await broadcast(update)
                elif kind == "stop":
                    break
            elif msg.get("bytes") is not None and session:
                updates = await run_in_threadpool(session.add_pcm16, msg["bytes"])
                for update in updates:
                    await ws.send_json(update)
                    if update["alert"]:
                        await broadcast(update)
    except WebSocketDisconnect:
        pass
    finally:
        if session:
            for update in await run_in_threadpool(session.flush):
                try:
                    await ws.send_json(update)
                except Exception:
                    break
            _save_live(session, "live")


@app.websocket("/ws/twilio")
async def ws_twilio(ws: WebSocket):
    """
    Real phone calls via Twilio Media Streams (see docs/REAL_WORLD.md).
    Twilio sends JSON events; audio is base64 mu-law 8 kHz. Alerts go to /ws/alerts
    listeners (your dashboard or phone). NOT TESTED: needs a Twilio account.
    """
    await ws.accept()
    session = LiveSession()
    call_sid = None
    try:
        while True:
            event = json.loads(await ws.receive_text())
            kind = event.get("event")
            if kind == "start":
                call_sid = event.get("start", {}).get("callSid")
            elif kind == "media":
                pcm = telephony.mulaw_to_pcm16_16k(base64.b64decode(event["media"]["payload"]))
                for update in await run_in_threadpool(session.add_pcm16, pcm):
                    update["call"] = call_sid
                    await broadcast(update)
            elif kind == "stop":
                break
    except WebSocketDisconnect:
        pass
    finally:
        _save_live(session, "phone-line")


@app.websocket("/ws/alerts")
async def ws_alerts(ws: WebSocket):
    """Dashboards or phones connect here to receive live alerts."""
    await ws.accept()
    alert_listeners.add(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        alert_listeners.discard(ws)


@app.get("/live")
def live_page():
    return FileResponse(os.path.join(FRONTEND, "live.html"))

if os.path.isdir(FRONTEND):
    app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
