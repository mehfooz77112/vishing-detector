"""
deepfake.py - estimate how likely a voice is AI-generated / cloned.

HONEST NOTE (say this to the judges): this is a lightweight BASELINE built
from acoustic features, not a state-of-the-art detector. Synthetic voices
often show:
  * unnaturally steady pitch (low pitch variation)
  * very smooth, uniform spectrum (low variation in spectral flatness)
  * unnaturally clean silence (almost no background noise between words)
  * missing/odd energy in the highest frequencies
We measure these, turn each into a 0-1 "suspicion" value, and average them.

To upgrade: set DEEPFAKE_MODEL to a Hugging Face audio-classification model
trained on ASVspoof / deepfake audio; it is used instead when available.
"""
import os
import wave

import numpy as np

SR = 16000
FRAME = 512
HOP = 256


def _load_audio(path):
    """Load audio as mono float array at 16 kHz. Tries wav first, then librosa."""
    try:
        with wave.open(path, "rb") as w:
            n, sr, ch, width = w.getnframes(), w.getframerate(), w.getnchannels(), w.getsampwidth()
            raw = w.readframes(n)
        dtype = {1: np.uint8, 2: np.int16, 4: np.int32}[width]
        x = np.frombuffer(raw, dtype=dtype).astype(np.float32)
        if width == 1:
            x = x - 128
        x /= float(np.iinfo(dtype).max if width != 1 else 128)
        if ch > 1:
            x = x.reshape(-1, ch).mean(axis=1)
    except Exception:
        import librosa                                    # handles mp3, webm, ogg...
        x, sr = librosa.load(path, sr=None, mono=True)
    if sr != SR and len(x):
        idx = np.linspace(0, len(x) - 1, int(len(x) * SR / sr))
        x = np.interp(idx, np.arange(len(x)), x)
    return x.astype(np.float32)


def _frames(x):
    n = 1 + (len(x) - FRAME) // HOP
    return np.stack([x[i * HOP: i * HOP + FRAME] * np.hanning(FRAME) for i in range(n)])


def _clip01(v):
    return float(min(1.0, max(0.0, v)))


def _pitch_track(fr, energy):
    """Rough pitch (Hz) per voiced frame using autocorrelation."""
    pitches = []
    lo, hi = int(SR / 400), int(SR / 70)
    thresh = np.percentile(energy, 60)
    for f, e in zip(fr, energy):
        if e < thresh:
            continue
        ac = np.correlate(f, f, mode="full")[FRAME - 1:]
        if ac[0] <= 0:
            continue
        ac = ac / ac[0]
        lag = lo + int(np.argmax(ac[lo:hi]))
        if ac[lag] > 0.35:
            pitches.append(SR / lag)
    return np.array(pitches)


def heuristic_score(x):
    if len(x) < SR * 1.0:
        return None, ["Audio too short (need at least 1 second)"], {}
    x = x / (np.max(np.abs(x)) + 1e-9)
    fr = _frames(x)
    energy = (fr ** 2).mean(axis=1)
    spec = np.abs(np.fft.rfft(fr, axis=1)) + 1e-10
    flat = np.exp(np.log(spec).mean(axis=1)) / spec.mean(axis=1)          # spectral flatness
    freqs = np.fft.rfftfreq(FRAME, 1 / SR)
    hf_ratio = (spec[:, freqs > 6000] ** 2).sum(axis=1) / ((spec ** 2).sum(axis=1) + 1e-12)
    voiced = energy > np.percentile(energy, 60)
    quiet = energy <= np.percentile(energy, 20)

    pitches = _pitch_track(fr, energy)
    pitch_cv = float(np.std(pitches) / np.mean(pitches)) if len(pitches) > 10 else None
    flat_var = float(np.std(flat[voiced])) if voiced.any() else 0.0
    noise_floor = float(np.sqrt(energy[quiet].mean())) if quiet.any() else 0.0
    hf = float(np.mean(hf_ratio))

    parts, reasons = [], []
    if pitch_cv is not None:
        s = _clip01((0.22 - pitch_cv) / 0.18)            # natural speech ~0.15-0.4
        parts.append(s)
        if s > 0.5:
            reasons.append("Pitch is unusually steady")
    s = _clip01((0.06 - flat_var) / 0.05)
    parts.append(s)
    if s > 0.5:
        reasons.append("Spectrum is unusually uniform")
    s = _clip01((0.004 - noise_floor) / 0.004)
    parts.append(s)
    if s > 0.5:
        reasons.append("Silence is unnaturally clean (no room noise)")
    s = _clip01((0.0005 - hf) / 0.0005)
    parts.append(s)
    if s > 0.5:
        reasons.append("Little high-frequency detail")

    feats = {"pitch_variation": pitch_cv, "spectral_flatness_variation": flat_var,
             "noise_floor": noise_floor, "high_freq_ratio": hf}
    return float(np.mean(parts)), reasons, feats


def _model_score(path):
    name = os.environ.get("DEEPFAKE_MODEL")
    if not name:
        return None
    try:
        from transformers import pipeline
        clf = pipeline("audio-classification", model=name)
        out = clf(path)
        fake_labels = ("fake", "spoof", "synthetic", "deepfake", "ai")
        return float(max((o["score"] for o in out
                          if any(k in o["label"].lower() for k in fake_labels)), default=0.0))
    except Exception:
        return None


def analyze_audio(path):
    """Return {'score': 0-1 or None, 'label': ..., 'reasons': [...], 'method': ...}."""
    try:
        m = _model_score(path)
        if m is not None:
            score, reasons, method = m, ["Pretrained model flagged synthetic speech"] if m > 0.5 else [], "pretrained-model"
        else:
            x = _load_audio(path)
            score, reasons, _ = heuristic_score(x)
            method = "acoustic-heuristic"
    except Exception as e:                                # never crash the whole call analysis
        return {"score": None, "label": "unknown", "reasons": [f"Could not analyse audio: {e}"],
                "method": "none"}
    if score is None:
        return {"score": None, "label": "unknown", "reasons": reasons, "method": method}
    label = "likely_synthetic" if score >= 0.6 else "uncertain" if score >= 0.4 else "likely_genuine"
    return {"score": round(score, 2), "label": label, "reasons": reasons, "method": method}


def analyze_samples(x):
    """Score a float32 numpy array (16 kHz). Same result format as analyze_audio."""
    try:
        score, reasons, _ = heuristic_score(np.asarray(x, dtype=np.float32))
    except Exception as e:
        return {"score": None, "label": "unknown", "reasons": [str(e)], "method": "none"}
    if score is None:
        return {"score": None, "label": "unknown", "reasons": reasons, "method": "acoustic-heuristic"}
    label = "likely_synthetic" if score >= 0.6 else "uncertain" if score >= 0.4 else "likely_genuine"
    return {"score": round(score, 2), "label": label, "reasons": reasons, "method": "acoustic-heuristic"}
