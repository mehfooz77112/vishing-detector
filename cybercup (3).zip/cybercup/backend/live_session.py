"""
live_session.py - analyse a call WHILE it is happening.

The idea (simple version):
  * Audio arrives as a stream of small pieces (PCM16, 16 kHz, mono).
  * We collect it into chunks of a few seconds (default 6 s).
  * Each chunk is turned into text (speech-to-text) and added to the call's
    transcript so far.
  * The WHOLE transcript so far is scored again after every chunk. That is the
    important difference from the upload mode: a scammer says "I am from the CBI"
    in minute 1 and "tell me the OTP" in minute 3, and only the combination is
    damning.
  * The alert level is STICKY: once a call reaches HIGH it stays HIGH. Otherwise
    a scammer (or the warning played on speaker, which the microphone hears
    again) could "talk the score back down".
  * Silent chunks are skipped, which saves CPU.
  * Audio is only held in memory and never written anywhere permanent.

Time to first warning is roughly: chunk length + speech-to-text time.
"""
import time

import numpy as np

import fraud_rules

SR = 16000
RANK = {"low": 0, "medium": 1, "high": 2}


def _default_transcriber(x):
    import transcribe
    if not transcribe.available():
        return ""
    return transcribe.transcribe_samples(x)[0]


def _default_voice_checker(x):
    import deepfake
    return deepfake.analyze_samples(x)["score"]


class LiveSession:
    def __init__(self, chunk_seconds=6, transcriber=None, voice_checker=None,
                 silence_rms=0.005, check_voice=True):
        self.chunk_samples = int(SR * chunk_seconds)
        self.silence_rms = silence_rms
        self._transcribe = transcriber or _default_transcriber
        self._voice_check = (voice_checker or _default_voice_checker) if check_voice else None
        self._pending = np.zeros(0, np.float32)     # audio not yet transcribed
        self._recent = np.zeros(0, np.float32)      # last 12 s, for the voice check
        self.samples_seen = 0
        self.texts = []
        self.level = "low"                          # sticky alert level
        self.alert_times = {}                       # level -> seconds into the call
        self.max_score = 0
        self.voice_score = None                     # smoothed synthetic-voice likelihood
        self.last = None
        self._started = time.time()

    # ---------- feeding audio / text ----------
    def add_pcm16(self, data):
        """Feed raw PCM16 little-endian bytes. Returns a list of update dicts."""
        usable = len(data) - (len(data) % 2)
        if usable == 0:
            return []
        x = np.frombuffer(data[:usable], dtype="<i2").astype(np.float32) / 32768.0
        self.samples_seen += len(x)
        self._pending = np.concatenate([self._pending, x])
        self._recent = np.concatenate([self._recent, x])[-SR * 12:]
        updates = []
        while len(self._pending) >= self.chunk_samples:
            chunk = self._pending[:self.chunk_samples]
            self._pending = self._pending[self.chunk_samples:]
            updates.append(self._process_chunk(chunk))
        return updates

    def add_text(self, text):
        """Feed already-transcribed text (used for tests and typed demos)."""
        return self._update(text)

    def flush(self):
        """Call at the end of a call: process any audio left over (needs 1+ second)."""
        if len(self._pending) >= SR:
            chunk, self._pending = self._pending, np.zeros(0, np.float32)
            return [self._process_chunk(chunk)]
        return []

    # ---------- internals ----------
    def _elapsed(self):
        return self.samples_seen / SR if self.samples_seen else time.time() - self._started

    def _process_chunk(self, chunk):
        rms = float(np.sqrt(np.mean(chunk ** 2)))
        if rms < self.silence_rms:
            return self._update("")                              # silence: nothing to do
        try:
            text = (self._transcribe(chunk) or "").strip()
        except Exception:
            text = ""
        if self._voice_check is not None and len(self._recent) >= SR * 3:
            try:
                s = self._voice_check(self._recent)
                if s is not None:
                    self.voice_score = s if self.voice_score is None else 0.6 * self.voice_score + 0.4 * s
            except Exception:
                pass
        return self._update(text)

    def _update(self, new_text):
        if new_text:
            self.texts.append(new_text)
        full = " ".join(self.texts)[-6000:]
        res = fraud_rules.analyze_text(full)

        # A very likely synthetic voice makes an already suspicious call worse.
        if (self.voice_score or 0) >= 0.6 and res["score"] >= 15:
            res["score"] = min(100, res["score"] + 25)
            res["indicators"].append({"id": "deepfake", "matched": "",
                                      "label": "Voice sounds synthetic / possibly cloned"})
            res["risk"] = "high" if res["score"] >= 60 else "medium" if res["score"] >= 30 else "low"

        escalated = False
        if RANK[res["risk"]] > RANK[self.level]:
            self.level = res["risk"]
            self.alert_times[self.level] = round(self._elapsed(), 1)
            escalated = self.level != "low"
        self.max_score = max(self.max_score, res["score"])

        self.last = {
            "type": "update",
            "elapsed": round(self._elapsed(), 1),
            "risk": self.level,                      # sticky level shown to the user
            "risk_now": res["risk"],                 # what the whole transcript scores right now
            "score": res["score"],
            "indicators": res["indicators"],
            "advice": fraud_rules.ADVICE[self.level],
            "new_text": new_text,
            "transcript": full,
            "language": res["language"],
            "deepfake_score": None if self.voice_score is None else round(self.voice_score, 2),
            "alert": escalated,                      # True only on the update that escalated
        }
        return self.last

    def summary(self):
        """Final result for the call history (transcript only, never audio)."""
        last = self.last or self._update("")
        return {"transcript": last["transcript"], "language": last["language"],
                "risk": self.level, "score": self.max_score, "indicators": last["indicators"],
                "advice": fraud_rules.ADVICE[self.level],
                "deepfake_score": last["deepfake_score"],
                "alert_times": self.alert_times, "duration": round(self._elapsed(), 1)}
