"""
telephony.py - turn phone-network audio into what our detector understands.

Phone providers such as Twilio and Exotel stream call audio as 8 kHz mu-law
(G.711), base64 encoded, in tiny 20 ms pieces. The detector wants 16 kHz PCM16.
These helpers convert it. No external packages needed (Python 3.13 removed
the old 'audioop' module, so we do it with numpy).
"""
import numpy as np


def mulaw_decode(data):
    """mu-law bytes -> int16 samples (still 8 kHz)."""
    u = np.bitwise_not(np.frombuffer(data, dtype=np.uint8)).astype(np.int32)
    sign = u & 0x80
    exponent = (u >> 4) & 0x07
    mantissa = u & 0x0F
    sample = (((mantissa << 3) + 0x84) << exponent) - 0x84
    return np.where(sign != 0, -sample, sample).astype(np.int16)


def mulaw_to_pcm16_16k(data):
    """mu-law 8 kHz bytes -> PCM16 16 kHz little-endian bytes."""
    x = mulaw_decode(data).astype(np.float32)
    if len(x) == 0:
        return b""
    idx = np.linspace(0, len(x) - 1, len(x) * 2)          # simple 2x upsampling
    up = np.interp(idx, np.arange(len(x)), x)
    return np.clip(up, -32768, 32767).astype("<i2").tobytes()


def mulaw_encode(samples):
    """int16 samples -> mu-law bytes. Only used by the tests (round-trip check)."""
    out = bytearray()
    for s in np.asarray(samples, dtype=np.int32):
        sign = 0x80 if s < 0 else 0
        s = min(abs(int(s)), 32635) + 0x84
        exponent, mask = 7, 0x4000
        while exponent > 0 and not (s & mask):
            exponent -= 1
            mask >>= 1
        mantissa = (s >> (exponent + 3)) & 0x0F
        out.append(~(sign | (exponent << 4) | mantissa) & 0xFF)
    return bytes(out)
