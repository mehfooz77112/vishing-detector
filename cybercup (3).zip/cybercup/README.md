# Call Guard - Vishing & Deepfake Voice Call Detector
Problem statement CC6-AI04 (Cyber Cup).

Call Guard listens to a call (recording, microphone, or pasted transcript), spots
scam tactics in Hindi, English and Hinglish, estimates whether the voice is
synthetic, and shows a risk level with plain advice.

## 1. Run it (10 minutes)

```
cd cybercup
python -m venv venv
venv\Scripts\activate            (Windows)     source venv/bin/activate   (Mac/Linux)
pip install -r requirements.txt
cd backend
uvicorn main:app --reload
```
Open **http://localhost:8000** in Chrome. Paste text and press *Analyse text*:
this works immediately. For audio, also install **ffmpeg**; the first audio
analysis downloads the Whisper model (a few minutes, once).
Set a smaller model if your laptop is slow: `set WHISPER_MODEL=base`.

Check the detector without the server: `python tests/evaluate.py`

## 2. How it fits together (explain this to the judges)

| Part | File | Job |
|---|---|---|
| Frontend | `frontend/index.html` | What the user sees: upload, mic, live monitor, risk meter, dashboard. Does no AI. |
| API | `backend/main.py` | The "waiter". `POST /analyze`, `GET /history`, `GET /stats`, `DELETE /history`. |
| Speech-to-text | `backend/transcribe.py` | Whisper turns audio into Hindi/English/Hinglish text. |
| Scam detector | `backend/fraud_rules.py` | Rules for each scam tactic, weighted and combined into a 0-100 score. |
| Deepfake check | `backend/deepfake.py` | Acoustic features (pitch steadiness, spectrum, silence noise) -> synthetic-likelihood. |
| Storage | `backend/db.py` | SQLite. Stores transcript + result only. Audio is deleted right after analysis. |
| Testing | `tests/` | Labeled calls, accuracy/false-alarm script, API tests. |

Flow of one call: audio -> API -> (deepfake check + Whisper transcript) -> scam rules
-> score -> LOW/MEDIUM/HIGH + reasons + safe-action advice (hang up, call back on the
official number, report on 1930) -> saved -> shown on screen.

### Why rules and not a big trained model?
No public labeled dataset of Indian vishing calls exists, and 24 hours is too short
to train one safely. Rules are fast, work on-device, and every decision is
explainable ("flagged because: asked for OTP + claimed to be CBI"). That
explainability is a requirement of the problem ("a clear reason"). The honest cost
is coverage (see section 4).

## 3. Results (be honest about these numbers)

`python tests/evaluate.py` runs `samples.json` (40 calls). Extra sets in
`hard_samples.json` and `blind_samples.json`.

**Important:** the first version of the rules scored 100% on `samples.json`,
but only because the rules and examples were written together. On new,
paraphrased calls it caught **0 of 6**, and on a second fresh set **3 of 10**
scams (30%). Patterns were then added to close those gaps, after which all
sets pass, **but those sets are now tuned-on, so 100% does not predict
real-world accuracy.** Treat roughly 30-60% detection on completely unseen,
differently-worded scams as the realistic expectation for a rule-based
approach, with a low false-alarm rate on ordinary calls.

**Tester task #1:** record or write 30+ NEW calls (different wording, real
voices, noise) in a file the developers do not look at, run them once, and report
that number in the presentation. Measuring it honestly will impress more than
a perfect score.

## 4. Known limitations (the problem asks for these)

- Rules only catch tactics they know. Cleverly reworded scams slip through; new
  scam scripts need new rules.
- Whisper makes mistakes with heavy accents, Hinglish spelling, phone-line
  noise and overlapping voices. If the transcript is wrong, the score is wrong.
- The deepfake check is a simple acoustic heuristic, not a state-of-the-art model.
  Good cloned voices, compressed phone audio and noisy rooms can fool it either
  way. It was only tried on artificial test tones, never on real cloned
  voices. To demo it properly, generate a sample with a text-to-speech tool and
  record a real voice, and report what happens. For better accuracy, set
  `DEEPFAKE_MODEL` to a Hugging Face anti-spoofing model.
- "Live" mode analyses 8-second chunks, so a warning comes a few seconds after
  the request, and each chunk is judged on its own (no memory of the earlier call).
- It cannot block calls or read caller-ID; it only analyses audio it is given.
- The API server and the Whisper path were written but could not be
  run where this was generated (no internet). Run `pytest tests/test_api.py` and
  fix anything that breaks.

## 5. Privacy (requirement 7)
- Analysis starts only after the consent box is ticked (the API also rejects `consent=false`).
- Audio goes to a temporary file that is deleted immediately after analysis.
- Only transcript, score and reasons are stored; "Delete all stored data" wipes it.
- Everything runs on your own machine; nothing is sent to an outside service
  (Whisper runs locally after its one-time model download).

## 6. Demo script (3 minutes)
1. Paste the "Digital arrest" example -> HIGH, reasons listed, advice shown.
2. Paste the "Genuine call" example -> LOW (shows it does not panic over everything).
3. Say a Hinglish OTP scam into the mic -> transcript, HIGH alert.
4. Upload a text-to-speech voice reading a scam -> deepfake score appears.
5. Open Dashboard -> history and most common tactics.
6. Show the evaluation numbers *and* the limitations slide.

## 7. Ideas if you have spare time (in order of value)
1. Collect more test calls and add rules for the ones missed.
2. Plug in a real anti-spoofing model (`DEEPFAKE_MODEL`).
3. Remember the whole call (combine chunk results) in live mode.
4. Add a small ML text classifier trained on your collected samples, and combine it with the rules.

## 8. AI assistance disclosure
This project was built by our team with the help of an AI assistant (Claude, by Anthropic),
which generated the first version of the code, test samples and documentation.
Our team's role: choosing the approach, running and testing it, finding the weaknesses
(see section 3), recording real test calls, and improving the rules. Check the
Cyber Cup rules on AI tool use and fill in which parts each member changed:

| Member | Module they own | What they changed / tested |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |

## 9. Live calls (real-time mode)
Open **http://localhost:8000/live** (or the "Live call mode" link on the main page).
It streams microphone audio to the server over a WebSocket, keeps the whole call in
context, shows a live transcript and risk score, and on HIGH speaks a warning in
English and Hindi and vibrates a phone. The alert is sticky: once HIGH, it stays HIGH.

Phones do not let apps tap a call, so for real calls use speakerphone, a telephony
line (Twilio/Exotel, code written but untested) or upload recordings. Everything
about this, timings, consent and the live test plan is in **docs/REAL_WORLD.md**.

Extra checks:
`python -m unittest tests.test_live_session -v`   (11 tests, no internet needed)

Measured claims to make: only numbers your tester measures (time to first warning,
detection rate, false alerts per hour). Do not say "instant".
