"""
test_api.py - checks that the API behaves correctly (for the tester).

Run from the cybercup folder (after pip install -r requirements.txt httpx pytest):
    pytest tests/test_api.py -v

NOTE FOR THE TEAM: this file was written but could not be executed in the
environment where it was created (no internet to install FastAPI). Run it
yourselves first and fix anything that fails. That is a good first
task for the tester.
"""
import os
import sys
import wave

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
from fastapi.testclient import TestClient  # noqa: E402

import db  # noqa: E402

db.DB_PATH = os.path.join(os.path.dirname(__file__), "test_calls.db")
import main  # noqa: E402

client = TestClient(main.app)

SCAM = "Sir I am from the bank. Your account will be blocked, share your OTP immediately."
SAFE = "Hi mom, I will be home by seven. Do you need anything from the market?"


@pytest.fixture(autouse=True)
def clean():
    db.init()
    db.clear()
    yield
    db.clear()


def test_health():
    assert client.get("/health").json()["status"] == "ok"


def test_scam_text_is_high_risk():
    r = client.post("/analyze", data={"text": SCAM}).json()
    assert r["risk"] in ("medium", "high")
    assert r["indicators"] and "1930" in r["advice"]


def test_genuine_text_is_low_risk():
    assert client.post("/analyze", data={"text": SAFE}).json()["risk"] == "low"


def test_requires_input():
    assert client.post("/analyze", data={}).status_code == 400


def test_requires_consent():
    assert client.post("/analyze", data={"text": SCAM, "consent": "false"}).status_code == 400


def test_history_and_stats_and_clear():
    client.post("/analyze", data={"text": SCAM})
    client.post("/analyze", data={"text": SAFE})
    assert len(client.get("/history").json()) == 2
    assert client.get("/stats").json()["total"] == 2
    client.delete("/history")
    assert client.get("/history").json() == []


def test_audio_upload_is_not_kept(tmp_path):
    path = tmp_path / "silence.wav"
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes(b"\x00\x00" * 16000 * 2)
    with open(path, "rb") as f:
        r = client.post("/analyze", files={"file": ("call.wav", f, "audio/wav")},
                        data={"text": SCAM})          # text given, so no Whisper needed
    assert r.status_code == 200
    assert "deepfake" in r.json()
