"""
test_live_session.py - tests for the live-call engine. No internet, Whisper or
FastAPI needed. Run from the cybercup folder:

    python -m unittest tests.test_live_session -v
"""
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
from live_session import LiveSession, SR  # noqa: E402
import telephony  # noqa: E402


def noise_bytes(seconds, amplitude=0.1):
    """Fake 'speech': loud random noise as PCM16 bytes (the transcriber is faked)."""
    rng = np.random.default_rng(0)
    x = rng.standard_normal(int(SR * seconds)) * amplitude
    return (np.clip(x, -1, 1) * 32767).astype("<i2").tobytes()


def scripted(lines):
    """A fake speech-to-text that 'hears' the given lines, one per chunk."""
    it = iter(lines)
    return lambda chunk: next(it, "")


class LiveSessionTests(unittest.TestCase):
    def run_call(self, lines, **kw):
        s = LiveSession(chunk_seconds=1, transcriber=scripted(lines), check_voice=False, **kw)
        updates = []
        for _ in lines:
            updates += s.add_pcm16(noise_bytes(1.0))
        return s, updates

    def test_scam_escalates_across_the_call(self):
        s, ups = self.run_call([
            "Hello sir I am calling from SBI bank.",
            "Your KYC is expired and your account will be blocked.",
            "Please share the OTP you received immediately.",
        ])
        self.assertEqual([u["risk"] for u in ups][0], "low")      # first line alone is harmless
        self.assertEqual(s.level, "high")
        self.assertTrue(any(u["alert"] for u in ups))
        self.assertIn("high", s.alert_times)

    def test_genuine_call_stays_low(self):
        s, ups = self.run_call(["Hi mom I will be home by seven.",
                                "Do you need anything from the market?"])
        self.assertEqual(s.level, "low")
        self.assertFalse(any(u["alert"] for u in ups))

    def test_alert_is_sticky(self):
        s, _ = self.run_call(["I am from the CBI. You are under digital arrest.",
                              "Transfer the money to the safe account now."])
        self.assertEqual(s.level, "high")
        # Warning heard again from the speaker must not lower the alert.
        up = s.add_text("Never share your OTP with anyone. Our staff will never ask for your OTP.")
        self.assertEqual(up["risk"], "high")

    def test_alert_flag_only_on_escalation(self):
        s, ups = self.run_call(["I am from the CBI. You are under digital arrest.",
                                "Transfer the money to the safe account now.",
                                "Do not tell anyone about this."])
        flagged = [u for u in ups if u["alert"]]
        self.assertGreaterEqual(len(flagged), 1)
        self.assertFalse(ups[-1]["alert"])                         # already high, no repeat alert

    def test_silence_is_skipped(self):
        calls = []
        s = LiveSession(chunk_seconds=1, transcriber=lambda c: calls.append(1) or "x",
                        check_voice=False)
        s.add_pcm16(b"\x00\x00" * SR * 2)                          # 2 s of silence
        self.assertEqual(calls, [])

    def test_odd_byte_count_is_safe(self):
        s = LiveSession(chunk_seconds=1, transcriber=scripted([]), check_voice=False)
        self.assertEqual(s.add_pcm16(b"\x01"), [])
        s.add_pcm16(noise_bytes(0.5) + b"\x01")                    # trailing odd byte ignored

    def test_summary_has_no_audio_and_has_alert_time(self):
        s, _ = self.run_call(["Share your OTP immediately or your account will be blocked."])
        sm = s.summary()
        self.assertIn(sm["risk"], ("medium", "high"))
        self.assertNotIn("audio", sm)
        self.assertGreater(sm["duration"], 0)

    def test_transcriber_failure_does_not_crash(self):
        def boom(_):
            raise RuntimeError("model missing")
        s = LiveSession(chunk_seconds=1, transcriber=boom, check_voice=False)
        ups = s.add_pcm16(noise_bytes(1.0))
        self.assertEqual(len(ups), 1)
        self.assertEqual(ups[0]["risk"], "low")


class TelephonyTests(unittest.TestCase):
    def test_mulaw_roundtrip(self):
        t = np.arange(800) / 8000
        original = (np.sin(2 * np.pi * 300 * t) * 12000).astype(np.int16)
        decoded = telephony.mulaw_decode(telephony.mulaw_encode(original)).astype(float)
        err = np.abs(decoded - original).max()
        self.assertLess(err, 700)                                   # mu-law is lossy, but close

    def test_upsample_doubles_length(self):
        out = telephony.mulaw_to_pcm16_16k(telephony.mulaw_encode(np.zeros(160, np.int16)))
        self.assertEqual(len(out), 160 * 2 * 2)                     # 2x samples, 2 bytes each

    def test_empty_input(self):
        self.assertEqual(telephony.mulaw_to_pcm16_16k(b""), b"")


if __name__ == "__main__":
    unittest.main()
