"""
evaluate.py - measures how good the detector is (the testers' main tool).

Run from the cybercup folder:
    python tests/evaluate.py

It reports:
  * accuracy             (how many calls were classified correctly)
  * detection rate       (scam calls that were flagged medium/high) = recall
  * false-alarm rate     (genuine calls wrongly flagged medium/high)
  * a per-language breakdown and a list of every mistake, so you can
    improve the rules and write the "limitations" section honestly.
A call is "flagged" when risk is medium or high.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "backend"))
import fraud_rules  # noqa: E402


def run(path=os.path.join(HERE, "samples.json")):
    samples = json.load(open(path, encoding="utf-8"))
    rows = []
    for s in samples:
        r = fraud_rules.analyze_text(s["text"])
        flagged = r["risk"] in ("medium", "high")
        rows.append({**s, "risk": r["risk"], "score": r["score"], "flagged": flagged,
                     "correct": flagged == (s["label"] == "scam")})
    return rows


def summarise(rows, title="ALL"):
    scams = [r for r in rows if r["label"] == "scam"]
    genuine = [r for r in rows if r["label"] == "genuine"]
    tp = sum(r["flagged"] for r in scams)
    fp = sum(r["flagged"] for r in genuine)
    acc = sum(r["correct"] for r in rows) / len(rows) if rows else 0
    print(f"{title:<10} calls={len(rows):<3} accuracy={acc:6.1%}  "
          f"scam detected={tp}/{len(scams)} ({tp / max(1, len(scams)):.0%})  "
          f"false alarms={fp}/{len(genuine)} ({fp / max(1, len(genuine)):.0%})")


if __name__ == "__main__":
    rows = run()
    summarise(rows)
    for lang in ("en", "hinglish", "hi"):
        summarise([r for r in rows if r["lang"] == lang], lang)
    print("\nMistakes:")
    bad = [r for r in rows if not r["correct"]]
    for r in bad:
        print(f"  [{r['id']}] truth={r['label']} predicted={r['risk']} score={r['score']} :: {r['text'][:70]}")
    if not bad:
        print("  none")
    print("\nHigh-risk threshold: scam calls that reached HIGH:",
          sum(r["risk"] == "high" for r in rows if r["label"] == "scam"),
          "/", sum(r["label"] == "scam" for r in rows))
    sys.exit(0)
