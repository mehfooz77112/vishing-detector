# Using Call Guard on real calls

Read this before the demo. It says what works today, what needs extra accounts,
and what is not possible, so you can answer judges honestly.

## The hard fact: phones do not let apps tap a call

- **iPhone:** no app can access call audio at all.
- **Android:** since Android 9, apps cannot record the in-call microphone or the
  other person's voice. Some phone brands ship a built-in call recorder, which
  works only inside that brand's dialer, and Google's Phone app can record in some
  regions and announces it to the other person.
- A web page or normal app therefore cannot "sit inside" a call. Real products
  solve this in one of the four ways below.

## Four ways to run it on real calls

| # | Method | Works today? | Latency | Needs |
|---|---|---|---|---|
| 1 | **Speakerphone + second device** running `/live` | Yes, built and runs | ~8-10 s to first warning | A laptop or second phone, any call |
| 2 | **Upload recordings** from the phone's own call recorder (main page, "Upload a recording") | Yes, built | After the call ends | A phone that records calls |
| 3 | **Telephony line** (Twilio / Exotel): calls are forwarded through a number that streams audio to `/ws/twilio` | Code written, NOT tested | ~8-10 s | Provider account, a public server, call forwarding |
| 4 | **Carrier / network level** (the telecom operator screens calls) | Out of scope | Real time | The operator |

### Method 1: speakerphone (use this for the demo)
1. Start the server (`uvicorn main:app --reload` in `backend/`).
2. Open `http://localhost:8000/live` on the laptop. Chrome allows the microphone on
   `localhost`. To use it from a phone on the same Wi-Fi you need HTTPS; the easy
   way is a tunnel such as `ngrok http 8000`, then open the https address it prints.
3. Tick consent, press **Start listening**, and put the real call on speaker next
   to the microphone. (Use headphones for the device that speaks the warning only
   if you can: the page keeps a high alert even if it re-hears its own warning.)
4. The page updates every few seconds with the transcript, risk, reasons and advice.
   On HIGH it speaks the warning in English and Hindi and vibrates (phones).

### Method 3: telephony line (the realistic "product" version)
```
Caller --> your Twilio/Exotel number --> (call is connected to you as normal)
                  |
                  +-- audio fork --> wss://YOUR-SERVER/ws/twilio --> detector
                                                    |
                          alerts --> /ws/alerts --> your dashboard / phone
```
Outline:
1. Rent a number from the provider. Callers (or you, by forwarding your SIM to it)
   reach you through it.
2. Return TwiML that connects the call and forks audio:
   `<Start><Stream url="wss://YOUR-SERVER/ws/twilio"/></Start><Dial>YOUR-REAL-NUMBER</Dial>`
3. Add an announcement at the start: "This call is analysed for fraud protection."
   (Consent, see below.)
4. Open `/ws/alerts` from your dashboard or an SMS/WhatsApp sender to push the warning.

Honest status: `/ws/twilio` and the mu-law audio conversion are written; the
conversion has a round-trip unit test, but the endpoint has never talked to a
real Twilio account. Expect to debug it. Exotel and other Indian providers have
similar streaming features with different message formats.

## Timing: how "live" is it?
- Audio is collected in 6-second chunks, then transcribed (Whisper `small` on a
  laptop CPU is typically a few seconds per chunk, an estimate that depends on your machine, so
  measure it; use `WHISPER_MODEL=base` for speed).
- First possible warning: about 7-10 seconds after the caller says the key phrase.
- The whole call stays in context, so a phrase in minute 1 still counts in minute 3.
- If transcription falls behind the audio, warnings get later. Measure it on your
  laptop and report the number; do not claim "instant".

## Consent, privacy and law (not legal advice)
- The problem statement requires consent. The page asks for it before starting and
  the server rejects a session without it. In a real deployment, announce it to
  the caller too.
- Call-recording and privacy rules vary and India's data-protection law applies to
  personal data. Have your team read the current rules before claiming this
  is deployable; for the contest, demonstrate with consenting volunteers and
  recorded test calls only.
- Audio is held in memory only; temporary files are deleted immediately; only the
  transcript and result are stored; the dashboard has a delete-everything button.
- Warn people not to use it to secretly monitor others. It is a protection tool for
  the person receiving the call.

## What to say about limits
- Cannot tap calls on iPhone/Android; needs speakerphone, a telephony line, or
  an operator.
- Warnings lag by the 6-second chunk plus transcription time; there is no word-by-word streaming; words split across chunk boundaries can be missed.
- Poor audio from a speakerphone (echo, background noise, accents, Hinglish) lowers
  transcription accuracy and therefore detection.
- Detection is rule-based; the honest unseen-data detection rate is in the README.
- The synthetic-voice check is a rough heuristic and is weaker on phone-quality
  audio, which is compressed and narrow-band.

## Test plan for live mode (tester)
1. Play each scripted scam recording through a phone speaker into the laptop mic
   and note: seconds until MEDIUM, seconds until HIGH, and whether it triggered at all.
2. Repeat with background noise (fan, traffic) and at 1 m distance.
3. Run genuine conversations (family, delivery, bank reminders) for 3+ minutes
   each and count false HIGH alerts.
4. Report: median time-to-warning, detection rate, false alerts per hour of
   genuine conversation.
